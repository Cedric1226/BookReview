from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login
from django.contrib import messages
from django.shortcuts import render, get_object_or_404, redirect
from .models import Book, BookReview
from django.contrib.auth.decorators import login_required
from .models import UserProfile
from .forms import UserProfileForm
from django.db.models import Q
from django.contrib.auth.models import User
from .models import User, UserFollowing
from datetime import date
from .models import UserCheckIn
from django.urls import reverse


def book_detail(request, book_id):
    book = get_object_or_404(Book, pk=book_id)
    recommended_books = book.recommended_books.all()

    # Only get the main reviews, not the replies
    main_reviews = BookReview.objects.filter(book=book, parent_review=None).order_by('-date_created')

    if request.method == "POST":
        if not request.user.is_authenticated:
            # Redirect to login page with next parameter
            # It will redirect back to book_detail after successful login
            login_url = reverse('login')
            next_url = reverse('book_detail', kwargs={'book_id': book.id})
            return redirect(f'{login_url}?next={next_url}')
        parent_review_id = request.POST.get('parent_review_id')  # Get the parent review ID from the form
        parent_review = None  # Default to None

        # Check for replies first
        if parent_review_id:
            parent_review = get_object_or_404(BookReview, id=parent_review_id)
            review_text = request.POST.get('review_text')
            review = BookReview(book=book, user=request.user, review_text=review_text, parent_review=parent_review)
            review.save()

        else:
            short_rating = request.POST.get('short_rating')
            short_review_text = request.POST.get('short_review_text')

            long_rating = request.POST.get('long_rating')
            long_review_text = request.POST.get('long_review_text')

            # Save short review
            if short_rating and short_review_text:
                review = BookReview(book=book, user=request.user, rating=short_rating, review_text=short_review_text,
                                    review_type='short')
                review.save()

            # Save long review
            if long_rating and long_review_text:
                review = BookReview(book=book, user=request.user, rating=long_rating, review_text=long_review_text,
                                    review_type='long')
                review.save()

        return redirect('book_detail', book_id=book.id)

    context = {
        'book': book,
        'main_reviews': main_reviews,
        'recommended_books': recommended_books,
    }
    return render(request, 'book_detail.html', context)


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Unsuccessful login, please check your username and password.')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})


def index(request):
    books = Book.objects.all()
    print(books)
    if 'query' in request.GET:
        query = request.GET['query']
        books = books.filter(
            Q(title__icontains=query) | Q(description__icontains=query) | Q(author_name__icontains=query))
        if books.exists():
            return redirect('book_detail', book_id=books.first().id)
    return render(request, 'index.html', {'books': books})


def contact_us(request):
    return render(request, 'contact_us.html')


def advertisement(request):
    return render(request, 'advertisement.html')


@login_required
def user_profile(request, username):
    viewed_user = get_object_or_404(User, username=username)
    profile, created = UserProfile.objects.get_or_create(user=viewed_user)
    is_following = request.user.following.filter(following_user=viewed_user).exists()
    titles_list = [title.strip() for title in viewed_user.userprofile.titles.split(',') if title.strip()]


    # If this is a POST request, then the form has been submitted
    if request.method == "POST":

        # Handle avatar upload/change
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()

        # Handle review and reply submission
        review_text = request.POST.get('review_text', '').strip()
        parent_review_id = request.POST.get('parent_review_id')

        if review_text and parent_review_id:  # If there's text to process and a parent review ID
            try:
                parent = BookReview.objects.get(pk=parent_review_id)

                new_reply = BookReview(
                    user=request.user,
                    review_text=review_text,
                    parent_review=parent,
                    book=parent.book  # Assigning the book from the parent review to the reply
                )

                new_reply.save()

            except BookReview.DoesNotExist:
                # Handle this if necessary; maybe set an error message
                pass

        return redirect('user_profile', username=viewed_user.username)
    else:
                form = UserProfileForm(instance=profile)

    reviews = viewed_user.bookreview_set.all()

    context = {
        'viewed_user': viewed_user,
        'current_user': request.user,
        'profile': profile,
        'form': form,
        'reviews': reviews,
        'is_following': is_following,
        'titles': titles_list,
    }

    return render(request, 'user_profile.html', context)


def check_in(request):
    if request.user.is_authenticated:
        last_checkin = UserCheckIn.objects.filter(user=request.user).last()
        if not last_checkin or last_checkin.date != date.today():
            UserCheckIn.objects.create(user=request.user)
            user_profile = UserProfile.objects.get(user=request.user)
            user_profile.add_points(1)
            messages.success(request, 'Checked in successfully! 1 point added.')
        else:
            messages.error(request, 'You have already checked in today.')
    else:
        messages.error(request, 'You need to be logged in to check in.')
    return redirect('user_profile', username=request.user.username)


@login_required
def friends_reviews(request):

    friends = [f.following_user for f in request.user.following.all()]

    reviews = BookReview.objects.filter(user__in=friends)

    context = {'reviews': reviews}
    return render(request, 'friends_reviews.html', context)


def follow_user(request, username):
    to_user = get_object_or_404(User, username=username)

    if request.user == to_user:
        messages.error(request, "You can't follow yourself.")
        return redirect('user_profile', username=username)

    # Checking if the user is already following the `to_user`
    is_following = UserFollowing.objects.filter(user=request.user, following_user=to_user).exists()

    if not is_following:
        user_follow = UserFollowing(user=request.user, following_user=to_user)
        user_follow.save()
        messages.success(request, f"You are now following {to_user.username}.")
    else:
        messages.info(request, f"You are already following {to_user.username}.")

    return redirect('user_profile', username=username)