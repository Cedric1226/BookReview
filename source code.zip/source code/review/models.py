from django.db import models
from django.contrib.auth.models import User
from imagekit.models import ImageSpecField
from imagekit.processors import ResizeToFill


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to='avatars/', default='avatars/default.jpeg')
    avatar_thumbnail = ImageSpecField(source='avatar',
                                processors=[ResizeToFill(100, 100)],
                                format='JPEG',
                                options={'quality': 60})
    points = models.PositiveIntegerField(default=0)
    titles = models.TextField(default='', blank=True)

    def add_points(self, num_points):
        self.points += num_points
        self.save()
        self.check_titles()

    def check_titles(self):
        titles_list = self.titles.split(',')
        if self.points >= 1 and 'New User Badge' not in titles_list:
            titles_list.append('New User Badge')
        if self.points >= 5 and 'Star Reader' not in titles_list:
            titles_list.append('Star Reader')
        self.titles = ','.join(titles_list)
        self.save()


class UserCheckIn(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)  # This automatically sets the current date when the record is created.


class Book(models.Model):
    title = models.CharField(max_length=200)
    author_name = models.CharField(max_length=200, null=True, blank=True)
    cover_image = models.ImageField(upload_to='books/covers/')
    description = models.TextField()
    amazon_link = models.URLField(blank=True, null=True, help_text="Link to buy this book on Amazon")
    recommended_books = models.ManyToManyField('self', blank=True)


REVIEW_CHOICES = (
    ("short", "Short Review"),
    ("long", "Long Review"),
)


class BookReview(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField(null=True, blank=True)
    review_text = models.TextField()
    date_created = models.DateTimeField(auto_now_add=True)
    parent_review = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name="replies")
    review_type = models.CharField(max_length=5, choices=REVIEW_CHOICES, default="short")


class UserFollowing(models.Model):
    user = models.ForeignKey(User, related_name="following", on_delete=models.CASCADE)
    following_user = models.ForeignKey(User, related_name="followers", on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)

    # def __str__(self):
    #     return self.title
