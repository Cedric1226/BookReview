
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('contact-us/', views.contact_us, name='contact_us'),
    path('advertisement/', views.advertisement, name='advertisement'),
    path('login/', views.user_login, name='login'),
    path('register/', views.register, name='register'),
    path('book/<int:book_id>/', views.book_detail, name='book_detail'),
    path('profile/<str:username>/', views.user_profile, name='user_profile'),
    path('follow/<str:username>/', views.follow_user, name='follow_user'),
    path('friends_reviews/', views.friends_reviews, name='friends_reviews'),
    path('check_in/', views.check_in, name='check_in'),

]
