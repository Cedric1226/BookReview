from django.contrib import admin
from .models import Book
from .models import BookReview


class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author_name')
    search_fields = ('title', 'author_name')
    filter_horizontal = ('recommended_books',)


admin.site.register(BookReview)
admin.site.register(Book)
